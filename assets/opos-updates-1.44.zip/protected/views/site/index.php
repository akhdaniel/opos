<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name;
?>

User : .... <br>
POS  : .... </br>

[<a href="<?php echo Yii::app()->baseUrl?>/posSession">Session</a>]