<!-- <li class="product_screen" onclick="insertOrder('<?php echo $data->id?>');">
	<div class="thumbnail">
		<?php if($data->image_url != null):?>
    	<img src="<?php echo $data->image_url?>" width="72" height="72">
    	<?php else: ?>
    	<img src="<?php echo Yii::app()->baseUrl?>/images/default.png" width="72" height="72">
    	<?php endif;?>
    	<div class="caption">
      		<p><?php echo CHtml::encode($data->name); ?></p>
    	</div>
  	</div>
</li> -->

<li>
<a href="#">Profile</a>
</li>