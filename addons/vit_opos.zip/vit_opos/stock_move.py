import logging
from osv import osv, fields
import openerp.tools
from openerp.tools.translate import _

_logger = logging.getLogger(__name__)

class stock_move(osv.osv):
	_inherit = "stock.move"
	_columns = {
		'shop_id' : fields.many2one('sale.shop', 'Shop'),
	}
	

stock_move()
