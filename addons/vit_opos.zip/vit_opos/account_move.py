from openerp import tools
from openerp.osv import osv, fields
from openerp.tools.translate import _


class account_move(osv.osv):
	_inherit = "account.move"
	_columns = {
		# 'shop_id' 		: fields.integer('Shop_id'),
		'shop_id' : fields.many2one('sale.shop', 'Shop'),
	}

account_move()